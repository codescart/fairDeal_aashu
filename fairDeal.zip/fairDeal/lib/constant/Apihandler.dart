import 'package:flutter/material.dart';

class verison{
  static const String versioncode="1.0.5";
}

class Api{
  static const String baseurl="https://realdeal.games/admin/index.php/Mobile_app/";
  static const String login= "userlogin";
  static const String homeprofile="profile_get?";
  static const String bettinghistory="bet_history?";
  static const String historyview="userget?";
}