package com.example.fairdeal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
