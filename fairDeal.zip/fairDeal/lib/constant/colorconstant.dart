

import 'package:flutter/material.dart';


 const Color loginbg= Color(0xff020819);
 const Color loginborder= Color(0xff0544c7);
 const Color border= Color(0xffffffff);
